#ifndef INGAMEFUNCTIONS_H
#define INGAMEFUNCTIONS_H
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>

int rollDice(int p1diceNum);
void displayP1Deck(int p1Deck[6]);
void displayP1CardList(int p1Deck[6]);
void displayPlayers();
void displayP1DeckCopy(int p1Deck[6]);
int chooseLevel(int p2HP);
void displayP1Attk();
void displayP2Attk();

#endif
