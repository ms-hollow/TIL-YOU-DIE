#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <windows.h>
#include <conio.h>
#include <string.h>
#include "ANSI_color_codes.h"


void SetCursorPosition(int x, int y);
int chooseLevel(int p2HP);


void menu(){

    system("cls");
    int pos = 1;
    int keyPressed = 0;
    int p2HP;


    while (keyPressed !=13) {
    system("cls");
     printf(BHWHT R"EOF(

                     __| |__________________________________________________________________________________________________________________________| |__
                    (__   __________________________________________________________________________________________________________________________   __)
                       | |   .    +     .         +   .   .      +             *                    +             *              .         .        | |
                       | |                .                              .                         .      .                                       . | |
                       | |           .-') _                     .                   *    .     . .      .      .  _ .-') _              ('-.     .  | |
                       | |          (  OO) )                                                                     ( (  OO) )           _(  OO)   .   | |
                       | |          /     '._ ,-.-')  ,--.            ,--.   ,--..-'),-----.  ,--. ,--.          \     .'_   ,-.-') (,------.       | |
                       | |     *   |'--...__)|  |OO) |  |.-')    +     \  `.'  /( OO'  .-.  ' |  | |  |     .    ,`'--..._)  |  |OO) |  .---'       | |
                       | |         '--.  .--'|  |  \ |  | OO )       .-')     / /   |  | |  | |  | | .-')        |  |  \  '  |  |  \ |  |      .    | |
                       | |     .      |  |   |  |(_/ |  |`-' |      (OO  \   /  \_) |  |\|  | |  |_|( OO )   .   |  |   ' |  |  |(_/(|  '--.      . | |
                       | |            |  |  ,|  |_.'(|  '---.'       |   /  /     \ |  | |  | |  | | `-' /       |  |   / : ,|  |_.' |  .--'        | |
                       | |            |  | (_|  |    |      |   *    `-./  /.   `'   '-'  '('  '-'(_.-'          |  '--'  /(_|  |    |  `---.       | |
                       | |      .     `--'   `--'    `------'      .   `--'          `-----'   `-----'       .   `-------'   `--'    `------'       | |
                       | |                                 .                                              +                     +        +          | |
                       | |         *        .                   +                   +           *                        .         .           .    | |
                       | |                        .                  .    *          .         .         .     .                      .             | |
                       | |                                                            .                                  .    *                .    | |
                     __| |__________________________________________________________________________________________________________________________| |__
                    (__   __________________________________________________________________________________________________________________________   __)
                       | |                                                                                                                          | |
    )EOF"WHT);

    SetCursorPosition(73,22); printf(BCYN"Use UP and DOWN Keys to Choose"BWHT);

    SetCursorPosition(75,24); arrowHere(1, pos); printf("START\n");
    SetCursorPosition(75,25); arrowHere(2, pos); printf("ABOUT\n");
    SetCursorPosition(75,26); arrowHere(3, pos); printf("EXIT\n");


    keyPressed = getch();

    if(keyPressed == 80 && pos !=5) {
        pos++;
    }else if(keyPressed == 72 && pos !=1){
        pos --;
    }else{
        pos==pos;
    }
    }

    if (pos == 1)
    {
        system("cls");
    } else if (pos == 2) {
        system("cls");
        aboutGame();
        printf("Press Enter");
        getch();
        menu();
    } else if (pos ==3){
        system("cls");
        exitGame(); // close program
        getch();
    }

}

void arrowHere(int realPosition, int arrowPosition) {
    if (realPosition == arrowPosition) {
        printf("---->>>");
    }else{
        printf("         ");
    }
}


void aboutGame(){
   printf(BCYN R"EOF(

                                                           ('-.    .-. .-')                            .-') _
                                                          ( OO ).-.\  ( OO )                          (  OO) )
                                                          / . --. / ;-----.\  .-'),-----.  ,--. ,--.  /     '._
                                                          | \-.  \  | .-.  | ( OO'  .-.  ' |  | |  |  |'--...__)
                                                        .-'-'  |  | | '-' /_)/   |  | |  | |  | | .-')'--.  .--'
                                                         \| |_.'  | | .-. `. \_) |  |\|  | |  |_|( OO )  |  |
                                                          |  .-.  | | |  \  |  \ |  | |  | |  | | `-' /  |  |
                                                          |  | |  | | '--'  /   `'  '-'  '('  '-'(_.-'   |  |
                                                          `--' `--' `------'      `-----'   `-----'      `--'


                                                              Kill your enemy first before they kill you.

                                A simple dice game that features 6 face-dice, health points, and 6 cards  based on the level you choose to play.

                                                                             'TIL YOU DIE

                                The title of the game came from the concept of the software itself, which is a battle between two players trying to
                            defeat each other through their luck and strategy. The term "die" can represent two meanings: (1) when the HP of a player
                                                become 0 and (2) A representation of luck which is the "dice" or "die" in singular.


                                                                            Game Overview

                            It's a turn-based game for two players [PLAYER 1] [COMPUTER], with each player getting a chance to roll dice every turn.
                                    The number of attacks and defense are  determined by the outcome of the rolled dice when the player pressed "R."

                                                                              What's New

                                Every round, players were given the option between attacking or defending with one of six cards from a deck of 6.
                                                            Your cards can always be stacked or void! Simply press "0"!


                                                                            Game Features

                                > Players were assigned a number of HP based on the level they choose.
                                > Levels of game includes: Easy, Average, Hard.
                                > Press "R" to roll dice.
                                > The results of the rolled dice corresponds to the number of attacks and defense of the player.
                                > Press "ENTER" to display the result of battle and stats of each player.
                                > Press "ENTER" to display the deck of cards and choose what number you want to use.


                                Play for free, roll dice, deck of  cards and win the game.


                                Game Information
                                Updated on                              Dec 11, 2021
                                Developed by                            Abbegail Miles Leonen
                                                                        John Paulo Alcantara
                                                                        Mark Argel Baustista
                                                                        Jolo Czark Ken Nario
                                                                        Harvey  Vinuya
                                                                        Laica Ygot
                                Released on                             Dec 15, 2021

                 )EOF"BWHT);


}

void exitGame(){
            printf(BCYN R"EOF(

                                                                              _ .-') _ .-. .-')                 ('-.
                                                                             ( (  OO) )\  ( OO )              _(  OO)
                                          ,----.     .-'),-----.  .-'),-----. \     .'_ ;-----.\  ,--.   ,--.(,------.
                                         '  .-./-') ( OO'  .-.  '( OO'  .-.  ',`'--..._)| .-.  |   \  `.'  /  |  .---'
                                         |  |_( O- )/   |  | |  |/   |  | |  ||  |  \  '| '-' /_).-')     /   |  |
                                         |  | .--, \\_) |  |\|  |\_) |  |\|  ||  |   ' || .-. `.(OO  \   /   (|  '--.
                                        (|  | '. (_/  \ |  | |  |  \ |  | |  ||  |   / :| |  \  ||   /  /     |  .--'
                                         |  '--'  |    `'  '-'  '   `'  '-'  '|  '--'  /| '--'  /`-./  /      |  `---.
                                          `------'       `-----'      `-----' `-------' `------'   `--'       `------'
                                    ('                          *                                  +                       _.._
                                    '|                                       ____                          *             .' .-'`
                                    |'                                    __(_   )__  o                                 /  /          +  .
                                   [::]                                 _(          )              .                   |  |
                                   [::]   _......_                     (     ) -----`                           *       \  '.___.;
                                   [::].-'      _.-`.         @         `---'                      ___                   '._,,_.'
                                   [:.'    .-. '-._.-`.                                          __)  )--.
                                   [/ /\   |  \        `-..                             .    ,-(         )_                         .
                                   / / |   `-.'      .-.   `-.              o                (     (       _)
                                  /  `-'            (   `.    `.                             `-(__  ___)-`            =( =     +
                                 |           /\      `-._/      \                    *             (__)
                                 '    .'\   /  `.           _.-'|
                                /    /  /   \_.-'        _.':;:/
                              .'     \_/             _.-':;_.-'
                             /   .-.             _.-' \;.-'
                            /   (   \       _..-'     |
                            \    `._/  _..-'    .--.  |                                                                     \   /
                             `-.....-'/  _ _  .'    '.|                ___                                                   .-.
                                      | |_|_| |      | \  (o)        _/ ..\                                                _/xx \
                                 (o)  | |_|_| |      | | (\'/)      ( \  3/__                                             ( \0  /__
                                (\'/)/  ''''' |     o|  \;:;         \    \__)                                             \/     _)
                                 :;  |        |      |  |/)          /     \                                               /      \_
                                  ;: `-.._    /__..--'\.' ;:        /      _\                                              \_.-.__  )
                                      :;  `--' :;   :;              `"""""``          _.------------.________________             '-'
                                       _.------'          `--+------._.---+--'
                                ----.___.-----'                                                                _________.----
                                                    _.------------.________________.-----------------'


                 )EOF"BWHT);
}

int chooseLevel(p2HP){
    int difficulty;
    gameMechanics();
    SetCursorPosition(55,34);
        printf(R"EOF(

                             _| |_______________________| |__       __| |_______________________| |_       _| |_______________________| |__
                            (__   ______________________   __)     (__   ______________________   __)     (__   ______________________   __)
                               | |                      | |           | |                      | |           | |                      | |
                               | |                      | |           | |                      | |           | |                      | |
                               | |         EASY         | |           | |        AVERAGE       | |           | |          HARD        | |
                               | |         (1)          | |           | |          (2)         | |           | |          (3)         | |
                               | |                      | |           | |                      | |           | |                      | |
                             __| |______________________| |__       __| |______________________| |__       __| |______________________| |__
                            (__   ______________________   __)     (__   ______________________   __)     (__   ______________________   __)
                               | |                      | |           | |                      | |           | |                      | |

    )EOF");
    SetCursorPosition(30,48); printf("Enter Level number: ");
    scanf("%d", &difficulty);

    if(difficulty == 1){
        p2HP = 10;
        return p2HP; }
    else if (difficulty == 2){
        p2HP = 20;
        return p2HP;}
    else if (difficulty == 3){
        p2HP = 30;
        return p2HP;}
    else { SetCursorPosition(30,28); printf("Invalid Level!"); getch(); system("cls"); chooseLevel(p2HP);}
}

 void gameMechanics(){
    printf(BHCYN R"EOF(
                 ________________________________________________________________________________________________________________________________________
                /\                                                                                                                                        \
            (O)===)><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><)==(O)
                \/'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''"'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''/
                (                                                                                                                                       (
                 )                                                                                                                                       )
                (                                                           Mechanics of the Game                                                       (
                 )                                                                                                                                       )
                        The game consists a [Player] and a [Computer], first one to DIE loses.
                (                                                                                                                                       (
                 )      All the player has to do is:                                                                                                     )
                (       - Press "R" or "Enter" To show the results of the battle and stats of the characters.                                           (
                 )      - We will be using a normal dice consisting  numbers from 1 to 6.                                                                )
                        -The players have 6 cards that they can activate anytime throughout the game.
                (       - The cards consists Extra Damage and Extra Defense, adding by +1 to +4                                                          (
                 )      - You can only use 1 card at a time, thus if the card is already used you cannot use it anymore.                                  )
                (       - After pressing "R", which means Roll Dice, the dice will get a random number from 1 to                                         (
                 )           6 which will become your Defense and Attack for that round.                                                                  )
                        - Then the game will ask you if you want to activate a card or not.
                 )           6 which will become your Defense and Attack for that round.                                                                 (
                (            If yes, you need to enter the card number and it will automatically add to your                                              )
                 )            current attack or defense for that round.                                                                                  (
                (       - Then the game will ask you if you want to activate a card or not.                                                               )
                             If yes, you need to enter the card number and it will automatically add to your current attack or defense for that round.
                (       - Then the game will ask you if you want to activate a card or not. If yes, you need to enter the card number and                (
                 )          it will automatically add to your current attack or defense for that round.                                                   )
                (       - After the 2 players rolled the dice and activate a card,                                                                       (
                 )          the 2 players will attack each other and defend themselves from the opponent's attack.                                        )
                        - Lastly the one who has not reach 0 HP wins the game.
                 )                                                                                                                                        )
                (                                                                                                                                        (
                /\''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""\
            (O)===)><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><><)==(O)
                \/________________________________________________________________________________________________________________________________________/


                  )EOF"BHWHT);
 }


void p1Won(){
     printf(R"EOF(
                                                                                                   (`-.      ('-.  _ .-') _
                                                                                                  _(OO  )_  _(  OO)( (  OO) )
                                  ,--.   ,--..-'),-----.  ,--. ,--.          ,--.      ,-.-') ,--(_/   ,. \(,------.\     .'_
                                   \  `.'  /( OO'  .-.  ' |  | |  |          |  |.-')  |  |OO)\   \   /(__/ |  .---',`'--..._)
                                 .-')     / /   |  | |  | |  | | .-')        |  | OO ) |  |  \ \   \ /   /  |  |    |  |  \  '
                                (OO  \   /  \_) |  |\|  | |  |_|( OO )       |  |`-' | |  |(_/  \   '   /, (|  '--. |  |   ' |
                                 |   /  /\_   \ |  | |  | |  | | `-' /      (|  '---.',|  |_.'   \     /__) |  .--' |  |   / :
                                 `-./  /.__)   `'  '-'  '('  '-'(_.-'        |      |(_|  |       \   /     |  `---.|  '--'  /
                                   `--'          `-----'   `-----'           `------'  `--'        `-'      `------'`-------'
    )EOF");
}

void p2Won(){
     printf(BRED R"EOF(
                                                                                         _ .-') _              ('-.
                                                                                        ( (  OO) )           _(  OO)
                                              ,--.   ,--..-'),-----.  ,--. ,--.          \     .'_   ,-.-') (,------.
                                               \  `.'  /( OO'  .-.  ' |  | |  |          ,`'--..._)  |  |OO) |  .---'
                                             .-')     / /   |  | |  | |  | | .-')        |  |  \  '  |  |  \ |  |
                                            (OO  \   /  \_) |  |\|  | |  |_|( OO )       |  |   ' |  |  |(_/(|  '--.
                                             |   /  /       |  | |  | |  | | `-' /       |  |   / : ,|  |_.' |  .--'
                                             `-./  /        '-'  '('  '-'(_.-'           |  '--'  /(_|  |    |  `---.
                                               `--'          `-----'   `-----'           `-------'   `--'    `------'

    )EOF"BWHT);
}


