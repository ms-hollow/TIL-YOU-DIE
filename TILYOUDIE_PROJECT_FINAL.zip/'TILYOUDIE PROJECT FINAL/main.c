#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <ctype.h>
#include <conio.h>
#include <string.h>
#include "titlescreen.h"
#include "inGameFuntions.h"
#include "ANSI_color_codes.h"

#define _WIN32_WINNT_WIN10 (0x0A00)


int bResult(int p1Att, int p1Def, int p2Att, int p2Def, int p1HP, int p2HP);
int p1ActivateCard(int ans, int p1Deck[6], int p1Att, int p1Def, int p1HP);
int p2ActivateCard(int ans, int p2Deck[6], int p2Att, int p2Def, int p2HP);


int main()
{
        //wag pansinin code to para sa window size
        HWND hwnd = GetConsoleWindow();
        if( hwnd != NULL ){ SetWindowPos(hwnd ,0,0,0 ,2000,2000,SWP_SHOWWINDOW|SWP_NOMOVE); }


        menu();


        ///////START NG FUNCTION NG GAME//////////
        int bResult(int p1Att, int p1Def, int p2Att, int p2Def, int p1HP, int p2HP);
        int p1ActivateCard(int ans, int p1Deck[6], int p1Att, int p1Def, int p1HP);
        int p2ActivateCard(int ans, int p2Deck[6], int p2Att, int p2Def, int p2HP);


        int p1diceNum, p2diceNum;
        int p1Att=0, p1Def=0, p1HP=20;
        int p2Att=0, p2Def=0, p2HP=0;
        int rolledDice, newHP, round=1;
        int p1Deck[6]={1,2,3,4,5,6}, p2Deck[6]={1,2,3,4,5,6};
        int ans, who, p1ans;
        char R;

        p2HP=chooseLevel(p2HP);
        //ROLL DICE
        //PLAYER 1 ROLL DICE
        do{
            do{
            system("cls");
            displayStatus(p1Att, p1Def, p1HP, p2Att, p2Def, p2HP);
            displayPlayers();
            SetCursorPosition(26,34);printf("Player 1 Enter 'R' to Roll Dice: ");
            scanf("%c", &R);
            R=toupper(R);
            if(R=='R')
                system("cls");
                {rolledDice=rollDice(p1diceNum);}
            }while(R!='R');

            p1Att=rolledDice;
            p1Def=rolledDice;
            SetCursorPosition(26,19); printf("You got %d", rolledDice);
            SetCursorPosition(26,20); printf("Press Enter.");
            getch();
            system("cls");
            displayStatus(p1Att, p1Def, p1HP, p2Att, p2Def, p2HP);
            displayPlayers();
            displayP1Deck(p1Deck);


            //PLAYER 2 ROLL DICE
            SetCursorPosition(26,40); printf("Press Enter to Show Player 2 Result.");
            getch();
            system("cls");
            rolledDice=rollDice(p1diceNum);
            p2Att=rolledDice;
            p2Def=rolledDice;
            SetCursorPosition(26,19); printf("Player 2 got %d", rolledDice);
            SetCursorPosition(26,20); printf("Press Enter.");
            getch();
            system("cls");
            displayStatus(p1Att, p1Def, p1HP, p2Att, p2Def, p2HP);
            displayPlayers();


            //ASK P1 IF ACTIVATE CARD
            if(p1Deck[0]>0 || p1Deck[1]>0 || p1Deck[2]>0 || p1Deck[3]>0 || p1Deck[4]>0 || p1Deck[5]>0){
                SetCursorPosition(27,33); printf("Press Enter to see list of cards. ");
                getch();
                system("cls");
                displayP1CardList(p1Deck);
                SetCursorPosition(26,26); printf("Do you want to activate card?\n\t\t\t  If Yes, type card order (Ex: '1'), otherwise enter 0: ");
                scanf("%d", &ans);
                system("cls");
                if(ans>0){
                    if(ans==1 || ans==3) {p1Def=p1ActivateCard(ans, p1Deck, p1Att, p1Def, p1HP);}
                    else if(ans==2 || ans==4){p1Att=p1ActivateCard(ans, p1Deck, p1Att, p1Def, p1HP);}
                    else if(ans==5 || ans==6){p1HP=p1ActivateCard(ans, p1Deck, p1Att, p1Def, p1HP);}
                    else{printf("Invalid Card");}
                    p1ans=ans;
                    SetCursorPosition(55,6); printf("PLAYER 1   HP: %d", p1HP);
                    SetCursorPosition(55,7); printf("ATT: %d", p1Att);
                    SetCursorPosition(55,8); printf("DEF: %d", p1Def);
                    displayP1DeckCopy(p1Deck);///////
                    }}
            else{SetCursorPosition(26,34); printf("You are out of cards."); getch(); system("cls");}

            //ASK P2 IF ACTIVATED CARD
            SetCursorPosition(55,18); printf("Press Enter to see opponent's activated card.");
            getch();
            //P2'S PROGRAM
            if(round%2==0) {ans=0; SetCursorPosition(55,20); printf("Opponent did not activate any card.");}
            if(round==5 || round==13 || round>15){ans=0; SetCursorPosition(55,20); printf("Opponent did not activate any card.");}
            else if(round==1){ans=2;} else if(round==3){ans=1;} else if(round==7){ans=4;} else if(round==9){ans=3;}
            else if(round==11){ans=5;} else if(round==15){ans=6;} else{ans=0;}


            if(ans>0){
                if(ans==1 || ans==3) {p2Def=p2ActivateCard(ans, p2Deck, p2Att, p2Def, p2HP);}
                else if(ans==2 || ans==4){p2Att=p2ActivateCard(ans, p2Deck, p2Att, p2Def, p2HP);}
                else if(ans==5 || ans==6){p2HP=p2ActivateCard(ans, p2Deck, p2Att, p2Def, p2HP);}
                else{printf("Opponent did not activated any card");}
                SetCursorPosition(55,21); printf("PLAYER 2   HP: %d", p2HP);
                SetCursorPosition(55,22); printf("ATT: %d", p2Att);
                SetCursorPosition(55,23); printf("DEF: %d",p2Def);
                }

            //BATTLE RESULTS
            newHP=bResult(p1Att, p1Def, p2Att, p2Def, p1HP, p2HP);
            if(p1Att>p2Att){p2HP=newHP;}
            else{p1HP=newHP;}
            if(p1HP<0){p1HP=0;}
            else if(p2HP<0){p2HP=0;}
            SetCursorPosition(30,5); printf("PLAYER 1 HP: %d", p1HP);
            SetCursorPosition(30,6); printf("PLAYER 2 HP: %d\n", p2HP);
            round++;
            p1Att=0, p1Def=0, p2Att=0, p2Def=0;

            if(p1HP<=0 || p2HP<=0 ){break;}

            SetCursorPosition(30,8); printf("Press Enter to proceed to next round");
        getch();
        }while(p1HP>0 || p2HP>0);

        if(p1HP<=0)
            {p2Won();}
        else{p1Won();}

        SetCursorPosition(30,20); printf("PRESS ENTER TO PLAY AGAIN");
        getch();
        main();

}
    //BRESULT
int bResult(int p1Att, int p1Def, int p2Att, int p2Def, int p1HP, int p2HP){

    int p1Dmg, p2Dmg;

        SetCursorPosition(55,24); printf("Press Enter to proceed to battle.");
        getch();
        system("cls");

        SetCursorPosition(27,5); printf("Player 1 will attack");
        displayP1Attk();
        p1Dmg=p2Def-p1Att;
        if(p1Dmg<0){p2HP=p2HP+p1Dmg;}
            if(p1Dmg<0){
            SetCursorPosition(27,30); printf("Player 1 damages Player 2 by %d", p1Dmg);}
            else{
            SetCursorPosition(27,30);printf("Player 2 successfully defended the attack");}
            getch();
            system("cls");

        SetCursorPosition(27,5); printf("Player 2 will attack");
        displayP2Attk();
        p2Dmg=p1Def-p2Att;
        if(p2Dmg<0){p1HP=p1HP+p2Dmg;}
            if(p2Dmg<0){
            SetCursorPosition(27,31); printf("Player 2 damages Player 1 by %d", p2Dmg);}
            else{
            SetCursorPosition(27,31); printf("Player 1 successfully defended the attack");}
            getch();
            system("cls");

        if(p1Att>p2Att){return p2HP;}
        else{return p1HP;}
}
  //P1 ACTIVATED CARD//
int p1ActivateCard(int ans, int p1Deck[6], int p1Att, int p1Def, int p1HP){

        do{
        if(ans==1 && p1Deck[0]==1) {p1Deck[0]=0; SetCursorPosition(55,3);
        printf("Player 1 activated card no.1 (Blue): +1DEF\n\t\t\t\t\t\t       1 was added to your DEF."); return p1Def+1;}
            else if(ans==1 && p1Deck[0]==0){SetCursorPosition(55,5); printf("This card is already used.");
                while(ans == 1){SetCursorPosition(55,6); printf("Please enter another card: "), scanf("%d", &ans); system("cls");}}
        if(ans==2 && p1Deck[1]==2) {p1Deck[1]=0; SetCursorPosition(55,3);
        printf("Player 1 activated card no.2 (Yellow): +2ATT\n\t\t\t\t\t\t       2 was added to your ATT."); return p1Att+2;}
            else if(ans==2 && p1Deck[1]==0){SetCursorPosition(55,5); printf("This card is already used.");
                while(ans == 2){SetCursorPosition(55,6);printf("Please enter another card: "), scanf("%d", &ans); system("cls");}}
        if(ans==3 && p1Deck[2]==3) {p1Deck[2]=0; SetCursorPosition(55,3);
        printf("Player 1 activated card no.3 (Orange): +3DEF\n\t\t\t\t\t\t       3 was added to your DEF."); return p1Def+3;}
            else if(ans==3 && p1Deck[2]==0){SetCursorPosition(55,5); printf("This card is already used.");
                while(ans == 3){SetCursorPosition(55,6); printf("Please enter another card: "), scanf("%d", &ans); system("cls");}}
        if(ans==4 && p1Deck[3]==4) {p1Deck[3]=0; SetCursorPosition(55,3);
        printf("Player 1 activated card no.4 (Red): +3ATT\n\t\t\t\t\t\t       3 was added to your ATT."); return p1Att+3;}
            else if(ans==4 && p1Deck[3]==0){SetCursorPosition(55,5); printf("This card is already used.");
                while(ans == 4){SetCursorPosition(55,6); printf("Please enter another card: "), scanf("%d", &ans); system("cls");}}
        if(ans==5 && p1Deck[4]==5) {p1Deck[4]=0; SetCursorPosition(55,3);
        printf("Player 1 activated card no.5 (Black): +2HP\n\t\t\t\t\t\t       2 was added to your HP."); return p1HP+2;}
            else if(ans==5 && p1Deck[4]==0){SetCursorPosition(55,5); printf("This card is already used.");
                while(ans == 5){SetCursorPosition(55,6); printf("Please enter another card: "), scanf("%d", &ans); system("cls");}}
        if (ans==6 && p1Deck[5]==6) {p1Deck[5]=0; SetCursorPosition(55,3);
        printf("Player 1 activated card no.6 (White): +4HP\n\t\t\t\t\t\t       4 was added to your HP."); return p1HP+4;}
            else if(ans==6 && p1Deck[5]==0){printf("This card is already used.");
                while(ans == 6){printf("Please enter another card: "), scanf("%d", &ans); system("cls");}}

        }while(ans>0 && ans<7);
}
///////////P2 ACTIVATED CARD////////////////////////////
int p2ActivateCard(int ans, int p2Deck[6], int p2Att, int p2Def, int p2HP){

        if(ans==1) {p2Deck[0]=0; SetCursorPosition(55,19); printf("1 was added to opponent's DEF."), p2Def=p2Def+1; return p2Def;}
        else if(ans==2) {p2Deck[1]=0; SetCursorPosition(55,19); printf("2 was added to opponent's ATT."), p2Att=p2Att+2; return p2Att;}
        else if(ans==3) {p2Deck[2]=0; SetCursorPosition(55,19); printf("3 was added to opponent's DEF."), p2Def=p2Def+3; return p2Def;}
        else if(ans==4) {p2Deck[3]=0; SetCursorPosition(55,19); printf("3 was added to opponent's ATT."), p2Att=p2Att+3; return p2Att;}
        else if(ans==5) {p2Deck[4]=0; SetCursorPosition(55,19); printf("2 was added to opponent's HP."), p2HP=p2HP+2; return p2HP;}
        else if(ans==5) {p2Deck[5]=0; SetCursorPosition(55,19); printf("4 was added to opponent's HP."), p2HP=p2HP+4; return p2HP;}

}

void SetCursorPosition(int x, int y) {

    HANDLE output = GetStdHandle(STD_OUTPUT_HANDLE);
    COORD pos = {x,y};
    SetConsoleCursorPosition(output, pos);

}
