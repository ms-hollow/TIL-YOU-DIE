#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <windows.h>

void menu();
void textcolor(int color);
int chooseLevel(int p2HP);
void p1Won();
void p2Won();
